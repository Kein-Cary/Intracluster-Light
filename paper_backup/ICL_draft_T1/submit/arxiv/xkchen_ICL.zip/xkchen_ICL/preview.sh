# !/bin/bash
latexmk -f -pvc -pdf -view=pdf ms.tex
